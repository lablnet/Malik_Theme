.ossn-search {
	
}
.ossn-search input[type='text']{
    width: 95%;
    margin: 0 auto;
    color: #000;
    margin-top: 10px;
    padding: 3px;
        padding-left: 6px;
    border-radius: 3px;
}