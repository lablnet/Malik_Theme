
<div class="sidemenu"id='hide_in_mobile'style="color:#73087f;">
 <?php
          			  if (ossn_is_hook('newsfeed', "sidebar:left")) {
                			$newsfeed_left = ossn_call_hook('newsfeed', "sidebar:left", NULL, array());
               				 echo implode('', $newsfeed_left);
            		}
           		 ?>                
</div>